﻿using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    [Header("Refs (kéo sẵn)")]
    public Rigidbody2D rb;
    public Transform player;
    public Animator anim;
    public SpriteRenderer sr;

    [Header("VFX & Timing")]
    public AnimationClip dieClip;

    [Header("Drop")]
    public EnemyLoot loot;

    bool deadHandled;

    void Awake()
    {
        // Tự bắt refs nếu quên kéo
        if (!rb) rb = GetComponent<Rigidbody2D>();
        if (!anim) anim = GetComponent<Animator>();
        if (!sr) sr = GetComponent<SpriteRenderer>();
        if (!player)
        {
            var p = GameObject.FindGameObjectWithTag("Player");
            if (p) player = p.transform;
        }

        // >>> Subscribe sự kiện chết
        var h = GetComponent<EnemyHealth>();
        if (h) h.onDied += HandleDeath;
    }

    void HandleDeath()
    {
        if (deadHandled) return;
        deadHandled = true;

        // rớt exp
        if (loot) loot.Drop();

        // tắt va chạm/di chuyển
        if (rb) rb.simulated = false;
        var col = GetComponent<Collider2D>(); if (col) col.enabled = false;
        var follow = GetComponent<EnemyFollow>(); if (follow) follow.enabled = false;

        // anim chết (nếu có)
        if (anim) anim.SetTrigger("Die");

        // huỷ sau 0.4s hoặc bằng độ dài clip
        float t = dieClip ? dieClip.length : 0.4f;
        Destroy(gameObject, t);
    }
}
