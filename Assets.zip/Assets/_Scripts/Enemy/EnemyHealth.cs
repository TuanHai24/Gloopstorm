﻿using UnityEngine;
using System;

[RequireComponent(typeof(Collider2D))]
public class EnemyHealth : MonoBehaviour
{
    public int maxHP = 3;
    public int hp;

    public event Action onDied;   // >>> AI sẽ subscribe

    bool dead;

    void Awake()
    {
        if (hp <= 0) hp = maxHP;
    }

    public void TakeDamage(int dmg)
    {
        if (dead) return;
        hp -= Mathf.Max(1, dmg);
        if (hp <= 0) Die();
    }

    void Die()
    {
        if (dead) return;
        dead = true;
        onDied?.Invoke();         // >>> báo cho EnemyAI (sẽ gọi Drop)
    }
}
