﻿using UnityEngine;
using TMPro; // nếu mày dùng TextMeshPro, còn không thì đổi qua UnityEngine.UI

public class WaveManager : MonoBehaviour
{
    public Camera mainCamera; // kéo camera vào Inspector
    public GameObject enemyPrefab;

    public int startEnemyCount = 5;
    public float timeBetweenWaves = 3f;

    private int currentWave = 0;
    private int aliveEnemies = 0;


    void Start()
    {
        StartNextWave();
    }

    void Update()
    {
        if (aliveEnemies <= 0 && !IsInvoking(nameof(StartNextWave)))
        {
            // Tạm delay trước khi bắt đầu wave mới
            Invoke(nameof(StartNextWave), timeBetweenWaves);
        }
    }

    void StartNextWave()
    {
        currentWave++;
        int enemyCount = startEnemyCount + currentWave * 2;

        for (int i = 0; i < enemyCount; i++)
        {
            Vector3 spawnPos = GetRandomSpawnPositionOutsideView();
            Instantiate(enemyPrefab, spawnPos, Quaternion.identity);
        }

        aliveEnemies = enemyCount;
    }

    Vector3 GetRandomSpawnPositionOutsideView()
    {
        // Lấy vị trí camera
        Vector3 camPos = mainCamera.transform.position;

        // Lấy kích thước camera theo orthographic
        float height = 2f * mainCamera.orthographicSize;
        float width = height * mainCamera.aspect;

        // Chọn 1 trong 4 cạnh: 0=trái, 1=phải, 2=trên, 3=dưới
        int edge = Random.Range(0, 4);

        Vector3 spawnPos = camPos;

        switch (edge)
        {
            case 0: // Trái
                spawnPos += new Vector3(-width / 2 - 1f, Random.Range(-height / 2, height / 2), 0);
                break;
            case 1: // Phải
                spawnPos += new Vector3(width / 2 + 1f, Random.Range(-height / 2, height / 2), 0);
                break;
            case 2: // Trên
                spawnPos += new Vector3(Random.Range(-width / 2, width / 2), height / 2 + 1f, 0);
                break;
            case 3: // Dưới
                spawnPos += new Vector3(Random.Range(-width / 2, width / 2), -height / 2 - 1f, 0);
                break;
        }

        spawnPos.z = 0; // quan trọng: đưa enemy lên mặt phẳng 2D
        return spawnPos;
    }

    public void OnEnemyDeath()
    {
        aliveEnemies--;
    }
}
