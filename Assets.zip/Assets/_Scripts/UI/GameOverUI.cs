﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverUI : MonoBehaviour
{
    public GameObject panel;

    void Start()
    {
        panel.SetActive(false);
    }

    public void Show()
    {
        panel.SetActive(true);
    }

    public void RestartGame()
    {
        Time.timeScale = 1f; // Đừng quên mở lại time
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
